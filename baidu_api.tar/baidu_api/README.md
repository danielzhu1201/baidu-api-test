please install ffmpeg first: sudo apt-get install ffmpeg

gbk编码对unicode编码中的表情报错:只提取中文其他替换为空

baidu-aip返回内部错误，目前原因不明确：可能包问题也有可能是api问题；

ValueError: do_handshake_on_connect should not be specified for non-blocking sockets:pip install requests[security]

http://zhannei.baidu.com/api/customsearch/keywords?title=%E6%88%91%E6%9D%A5%E6%B5%8B%E8%AF%95%E6%A0%87%E9%A2%98%E5%88%86%E8%AF%8D%E6%95%88%E6%9E%9C%E6%98%AF%E5%90%A6%E6%AD%A3%E5%B8%B8%E6%80%9D%E5%AF%86%E8%BE%BE

per:人名不细分，其他词性细分
nw:作品名字不做细分
